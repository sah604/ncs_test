package com.greedy.section02.extend;

public class Mammal implements Animal {
	
	/* 포유류도 동물이기 때문에 Animal 인터페이스를 상속받는다. */

}
