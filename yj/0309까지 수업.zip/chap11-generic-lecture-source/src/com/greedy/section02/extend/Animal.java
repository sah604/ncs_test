package com.greedy.section02.extend;

public interface Animal {
	
	/* 해당 인터페이스를 상속받는 Mammal(포유류) 클래스를 만들자 */

}
