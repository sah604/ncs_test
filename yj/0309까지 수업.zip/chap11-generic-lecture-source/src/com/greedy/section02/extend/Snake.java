package com.greedy.section02.extend;

public class Snake extends Reptile {

	
}
