package com.greedy.section02.extend;

public class Reptile implements Animal {
	
	/* 파충류도 동물이기에 Animal 인터페이스를 상속받는다 */
}
