package com.greedy.section02.demensional_array;

public class Jooso {
	public static void main(String[] args) {
		
		int[] arr = new int[5];
		
		arr[1] = 30;
		System.out.println(arr[1]);
		
		arr = new int[10];
		
		System.out.println(arr[1]);
		
		
	}

}
