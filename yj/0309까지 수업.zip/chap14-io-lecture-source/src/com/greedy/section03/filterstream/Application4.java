package com.greedy.section03.filterstream;

import com.greedy.section03.filterstream.vo.MemberVO;

public class Application4 {
	
	public static void main(String[] args) {
		
		// 객체 단위로 입출력을 하기위한 ObjectInputStream/ ObjectOutputStream
		
		MemberVO[] outputMembers = {
				new MemberVO("user01","pass01", "홍길동", "hong@gredy.com",25,'남',1250.7),
				new MemberVO("user02","pass02", "유관순", "korea@gredy.com",16,'여',1550.6),
				new MemberVO("user03","pass03", "이순신", "mr.lee@gredy.com",22,'남',1234.5)
		};
		
		
		
		
		
		
		
		
		
		
	}

}
