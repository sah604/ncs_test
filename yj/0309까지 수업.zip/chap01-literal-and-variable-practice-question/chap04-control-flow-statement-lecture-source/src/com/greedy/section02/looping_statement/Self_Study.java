package com.greedy.section02.looping_statement;

public class Self_Study {
	
	
	public void selfStudyForPDFQuiz() { // while & for
		
		int first = 0; // 초기식 선언
		
		while(first <= 10) {
			
			
			
		}
		
		
		
	}

}
