package com.greedy.section02.looping_statement;

public class Application {

	public static void main(String[] args) {
		
		// TODO 흐름 확인은 디버그 모드에서!!!!!
		
		// 반복문 테스트 클래스들을 호출하기 위한 main()을 포함한 실행용 클래스
		
		//A_for a = new A_for();
		
		/* 단독 for문 흐름 확인용 메소드 호출 */
		//a.testSimpleForStatement();
		
		
		//a.testForExample1();
		
		//a.testForExample2();
		
		
		//a.testForExample4();
		
		
		//a.printSimpleGugudan();
		
		//a.printSimpleGugudan();
		
		
		//A_nestedFor a2 = new A_nestedFor();
		
		//a2.printGugudanFromTwoToNine();
		
		//a2.printStarInputRowTimes();
		
		//a2.printTriangleStarts();
		
		
		//B_while b1 = new B_while();
		
		//b1.testSimpleWhileStatement();
		
		//b1.testWhileExample1();
		
		//b1.testWhileExample2();
		
		//b1.testWhileExample3();
		
		C_doWhile c = new C_doWhile();
		
		//c.testSimpleDoWhileStatement();
		
		c.testDoWhileExample1();
		
	}
	
	
}
