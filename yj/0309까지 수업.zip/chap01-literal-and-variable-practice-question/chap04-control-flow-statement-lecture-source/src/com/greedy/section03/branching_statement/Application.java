package com.greedy.section03.branching_statement;

public class Application {

	public static void main(String[] args) {
		
		A_break a = new A_break();
		
		//a.testSimpleBreakStatement();
		
			
		B_continue b = new B_continue();
		
		//b.testSimpleContiuneStatement();

		//b.testSimpleContiuneStatement2();
		
		b.testJumpContiune();
		
	}

}
