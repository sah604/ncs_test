package com.greedy.level02.normal;

public class Application {
	public static void main(String[] args) {
		
		Random ran = new Random();
		
		ran.randomNumber(-35, 20);
		
		ran.randomUpperAlphabet(10);
		
		ran.rockPaperScissors();
		
		ran.tossCoin();
		
		
	}

}
