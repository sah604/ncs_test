package com.greedy.level01.basic;

public class Application {
	public static void main(String[] args) {
		
		Calculator cal = new Calculator();
		
		cal.sum1to10();
		
		cal.checkMaxNumber(10, 20);
		
		cal.sumTwoNumber(10, 20);
		
		cal.minusTwoNumber(10, 5);
		
		
		
	}

}
