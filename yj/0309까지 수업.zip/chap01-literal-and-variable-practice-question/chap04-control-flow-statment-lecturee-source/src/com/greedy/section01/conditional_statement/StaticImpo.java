package com.greedy.section01.conditional_statement;

public class StaticImpo {
	public static void print1(){
		System.out.println("static 메소드 호출 성공..");
	}
}
