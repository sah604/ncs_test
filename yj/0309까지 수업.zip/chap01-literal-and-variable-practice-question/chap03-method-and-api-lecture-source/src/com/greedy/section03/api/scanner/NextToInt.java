package com.greedy.section03.api.scanner;

public class NextToInt {

}
