package com.greedy.section03.api.math;

public class Test {
	public static void main(String[] args) {
		
		App met = new App();
		met.add(9, 8);
		
		App.snum1();
		
	}

	

}
