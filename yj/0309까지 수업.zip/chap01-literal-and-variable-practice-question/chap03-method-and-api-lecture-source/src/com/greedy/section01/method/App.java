package com.greedy.section01.method;

public class App {
	String jooso = " 쌍문동";
	
	
	public void autoAddressGen(String address, int floor) {
		System.out.println("주소는 : " + address);
	}

}
