package com.greedy.section04.override;

import java.io.IOException;

public class SuperClass {

	   public void method() throws IOException{

		      
	   }
}