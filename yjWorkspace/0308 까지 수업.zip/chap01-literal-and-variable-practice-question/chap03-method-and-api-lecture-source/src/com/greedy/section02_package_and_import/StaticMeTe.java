package com.greedy.section02_package_and_import;

public class StaticMeTe {
	
	public static int  add1 (int n1, int n2) {
		int result = n1+n2;
		int add  = result;
		System.out.println(add);
		return add;
	}

}
