package com.greedy.section02_package_and_import;


//import static com.greedy.section01.method.StaticTest.add;

import com.greedy.section01.method.StaticTest;

public class StaticConfirm {
	public static void main(String[] args) {
		
		
		
		StaticTest.add(55, 4);
	}

}
