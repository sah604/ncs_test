package com.greedy.section01.method;

public class Application0 {
	public static void main(String[] args) {

		Application0 app = new Application0();
		app.name();

	}
	public static void name () {
		String name = "�ο���";
		
		System.out.println(name);
	}
}
