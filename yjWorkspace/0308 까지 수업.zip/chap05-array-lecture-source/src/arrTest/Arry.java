package arrTest;

import com.greedy.section03.array_copy.ArrayIm;

public class Arry {
	public static void main(String[] args) {
		
		ArrayIm ar1 = new ArrayIm();
		
		
		
	}
	
	ArrayIm ar1 = new ArrayIm();
	
	

}
