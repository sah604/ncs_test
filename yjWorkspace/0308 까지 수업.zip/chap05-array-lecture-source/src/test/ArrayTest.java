package test;

public class ArrayTest {
	
	
		
		int[] arry = new int[5];
		 
		// arry[1] = 5; 메인 클래스가 아닌곳에는 사용불가
		
		public void anoPaka() {
			System.out.println("다른 패키지에서 출력");
		}
		
	
}
