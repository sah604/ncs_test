package test;

public class ArrayImpo {
	public static void main(String[] args) {
		
		ArrayTest arr = new ArrayTest();
		
		
		System.out.println(arr.arry);
		
		arr.arry[1] = 5;
		
		
	}
	
	

}
