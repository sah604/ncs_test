package com.greedy.section03.array_copy;

public class ArrayIm {
	
	int[] arr = new int[5];
	

}
