package com.greedy.section02.demensional_array.level03.hard;

import java.util.Scanner;

public class Application2 {
	
	public static void main(String[] args) {
		
		/* 홀수를 하나 입력 받아 입력받은 크기 만큼의 정사각형 형태의 2차원 배열을 할당하고
		 * 모래시계 모양으로 *을 출력하세요
		 * 
		 * -- 입력 예시 --
		 * 홀수 하나를 입력하세요 : 5
		 * 
		 * -- 출력 예시 --
		 * *****
         *  *** 
         *   *  
         *  *** 
         * *****
         * 
         * 단, 홀수를 입력하지 않은 경우 "홀수만 입력해야 합니다." 출력
		 * */
		
	}
	
}
