package com.greedy.section02.encapslation.problem2;

public class Monster {
	
	/* 몬스터 정보를 저장할 필드 작성 */
	//String name;
	String kinds;
	int hp;

}
