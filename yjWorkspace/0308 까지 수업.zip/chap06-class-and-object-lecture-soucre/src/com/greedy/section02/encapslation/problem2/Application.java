package com.greedy.section02.encapslation.problem2;

public class Application {
	public static void main(String[] args) {
		
		/* 필드에 바로 접근할 때 발생할 수 있는 문제점2 */
		/*
		 * 필드의 이름이나 자료형을 변경할 때 사용한 쪽 코드를 수정해야하는 경우가 생긴다.
		 * 즉, 작은 변경이 사용하는 다른 여러곳의 변경도 함께 초래하게 된다.
		 * 
		 * */
		
		/* monster 3마리 추가 */
//		Monster monster1 = new Monster();
//		monster1.name = "드라큘라";
//		monster1.hp = 200;
//		
//		Monster monster2 = new Monster();
//		monster2.name = "프랑켄";
//		monster2.hp = 300;
//		
//		Monster monster3 = new Monster();
//		monster3.name = "미이라";
//		monster3.hp = 400;
//		
//		System.out.println("monster1 name : " + monster1.name);
//		System.out.println("monster1 hp : " + monster1.hp);
//		
//		System.out.println("monster2 name : " + monster2.name);
//		System.out.println("monster2 hp : " + monster2.hp);
//		
//		System.out.println("monster3 name : " + monster3.name);
//		System.out.println("monster3 hp : " + monster3.hp);
//		
//		
//		
		
		
		
		
		
		
	}

}
