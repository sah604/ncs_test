package com.greedy.section02.encapslation.problem1;

public class PrivateTest {

}
