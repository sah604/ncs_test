package com.greedy.section02.extend;

public class Rabbit extends Mammal {
	
	public void cry() {
		System.out.println("토끼가 울음 소리를 낸다. 끾끾!");
		
	}
	
}
