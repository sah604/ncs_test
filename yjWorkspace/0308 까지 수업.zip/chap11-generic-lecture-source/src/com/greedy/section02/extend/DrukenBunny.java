package com.greedy.section02.extend;

public class DrukenBunny extends Bunny {

	@Override
	public void cry() {
		
		System.out.println("봐니봐니 뵈니뵈니 댕근댕근@@");
	}
	
	public void cryD() {
		
		System.out.println("운다~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	
}
