package com.greedy.collection.silsub.view;

public class BookMenu {
	

	public BookMenu() {}
	
	public void menu() {
		
	}
	

}
