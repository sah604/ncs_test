package com.greedy.section02.looping_statement;

public class Application {

	public static void main(String[] args) {
	
		// 반복문 테스트 클래스들을 호출하기 위한 main() 포함한 실행용 클래스
		
		A_for a = new A_for();
		
		/* 단독 for문 흐름 확인용 메소드 호출 */
		//a.testSimpleForStatement();
		
		
		//a.testForExample1();
		
		//a.testForExample2();
		
		a.testForExample3();
	}
}
